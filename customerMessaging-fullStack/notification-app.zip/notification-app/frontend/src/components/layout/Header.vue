<template>
        <header class="page-header light-blue">
            <span d="nav-mobile" class="white-text">&copy; Multi-Language Notification System</span>
        </header>
</template>


<script>
export default {
    name: 'Header',
    data(){
        return {

        }
    }
}
</script>
<style>
.page-header{
    padding: 20px;
}
</style>